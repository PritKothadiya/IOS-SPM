//
//  MYSDK.h
//  MYSDK
//
//  Created by Prit Kothadiya on 10/10/23.
//

#import <Foundation/Foundation.h>

//! Project version number for MYSDK.
FOUNDATION_EXPORT double MYSDKVersionNumber;

//! Project version string for MYSDK.
FOUNDATION_EXPORT const unsigned char MYSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MYSDK/PublicHeader.h>


